import { useElementStore } from "../stores/elementStore";
import { useShallow } from "zustand/react/shallow";
import { findElement } from "../utils/elementUtils";

export const useSelectedElement = () => {
  const { elements, selectedElementId } = useElementStore(
    useShallow((state) => ({
      elements: state.elements,
      selectedElementId: state.selectedElementId,
    }))
  );

  const selectedElement =
    findElement(elements, selectedElementId || "") || null;

  return selectedElement;
};
