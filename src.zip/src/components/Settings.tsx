import type {
  GroupElement,
  TextElement,
  InputElement,
} from "../types/elements";

interface SettingsProps {
  selectedElement: GroupElement | TextElement | InputElement | null;
  handleContentChange: (content: string) => void;
  handleStyleChange: (
    styles:
      | Partial<GroupElement["styles"]>
      | Partial<TextElement["styles"]>
      | Partial<InputElement["styles"]>
  ) => void;
}

const renderGroupSettings = (
  element: GroupElement,
  onStyleChange: (styles: Partial<GroupElement["styles"]>) => void
) => (
  <div className="space-y-4">
    <h3 className="text-md font-medium text-gray-800 capitalize">
      그룹 {element.id.split("-")[1]} 요소 설정
    </h3>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        너비
      </label>
      <input
        type="text"
        value={element.styles.width?.toString() || ""}
        onChange={(e) => onStyleChange({ width: e.target.value })}
        placeholder="300px"
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
    </div>

    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        높이
      </label>
      <input
        type="text"
        value={element.styles.height?.toString() || ""}
        onChange={(e) => onStyleChange({ height: e.target.value })}
        placeholder="200px"
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
    </div>
  </div>
);

const renderTextSettings = (
  element: TextElement,
  onContentChange: (content: string) => void,
  onStyleChange: (styles: Partial<TextElement["styles"]>) => void
) => (
  <div className="space-y-4">
    <h3 className="text-md font-medium text-gray-800 capitalize">
      텍스트 설정
    </h3>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        텍스트 색상
      </label>
      <input
        type="color"
        value={element.styles.color?.toString() || "#000000"}
        onChange={(e) => onStyleChange({ color: e.target.value })}
        className="w-full h-10 border border-gray-300 rounded-md cursor-pointer"
      />
    </div>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        텍스트 크기
      </label>
      <input
        type="text"
        value={element.styles.fontSize?.toString() || ""}
        onChange={(e) => onStyleChange({ fontSize: e.target.value })}
        placeholder="200px"
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
    </div>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        텍스트 굵기
      </label>
      <select
        value={element.styles.fontWeight?.toString() || "400"}
        onChange={(e) => onStyleChange({ fontWeight: e.target.value })}
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <option value="300">Light</option>
        <option value="400">Normal</option>
        <option value="500">Medium</option>
        <option value="600">Semi Bold</option>
        <option value="700">Bold</option>
      </select>
    </div>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        텍스트 내용
      </label>
      <input
        type="text"
        value={element.content}
        onChange={(e) => onContentChange(e.target.value)}
        placeholder="Enter text..."
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
    </div>
  </div>
);

const renderInputSettings = (
  element: InputElement,
  onStyleChange: (styles: Partial<InputElement["styles"]>) => void
) => (
  <div className="space-y-4">
    <h3 className="text-md font-medium text-gray-800 capitalize">인풋 설정</h3>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        텍스트 크기
      </label>
      <input
        type="text"
        value={element.styles.fontSize?.toString() || ""}
        onChange={(e) => onStyleChange({ fontSize: e.target.value })}
        placeholder="16px"
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
    </div>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        텍스트 굵기
      </label>
      <select
        value={element.styles.fontWeight?.toString() || "400"}
        onChange={(e) => onStyleChange({ fontWeight: e.target.value })}
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <option value="300">Light</option>
        <option value="400">Normal</option>
        <option value="500">Medium</option>
        <option value="600">Semi Bold</option>
        <option value="700">Bold</option>
      </select>
    </div>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        텍스트 색상
      </label>
      <input
        type="color"
        value={element.styles.color?.toString() || "#000000"}
        onChange={(e) => onStyleChange({ color: e.target.value })}
        className="w-full h-10 border border-gray-300 rounded-md cursor-pointer"
      />
    </div>
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        배경색
      </label>
      <input
        type="color"
        value={element.styles.backgroundColor?.toString() || "#ffffff"}
        onChange={(e) => onStyleChange({ backgroundColor: e.target.value })}
        className="w-full h-10 border border-gray-300 rounded-md cursor-pointer"
      />
    </div>
  </div>
);

const Settings: React.FC<SettingsProps> = ({
  selectedElement,
  handleContentChange,
  handleStyleChange,
}) => {
  if (!selectedElement) {
    return (
      <div className="bg-white p-6 w-80">
        <h2 className="text-lg font-medium text-gray-900 mb-4">설정</h2>
        <p className="text-gray-500">요소를 선택하여 속성을 편집하세요</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 border-gray-200 w-80">
      <h2 className="text-lg font-medium text-gray-900 mb-4 min-w-60">설정</h2>
      {selectedElement.type === "group" &&
        renderGroupSettings(selectedElement as GroupElement, handleStyleChange)}
      {selectedElement.type === "text" &&
        renderTextSettings(
          selectedElement as TextElement,
          handleContentChange,
          handleStyleChange
        )}
      {selectedElement.type === "input" &&
        renderInputSettings(selectedElement as InputElement, handleStyleChange)}
    </div>
  );
};

export default Settings;
